$(document).ready(function () {
    var content = [];

    $(".accion").click(function (event) {
       
        $(this).parent().parent().parent().children().each(function (index, element) {
            content[index] = $(this).text();

        });
        $(this).siblings('#id').val(content[0]);
        $(this).siblings('#nombre').val(content[1]);
        $(this).siblings('#nit').val(content[2]);

    });
});