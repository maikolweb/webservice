<?php

require_once '../config/Conexion.php';
require_once '../model/dao/TransportadoraDao.php';
require_once '../model/dto/TransportadoraDto.php';



if (isset($_POST['registro'])) {




    $traDao = new TransportadoraDao();
    $traDto = new TransportadoraDto();

    $traDto->setId($_POST['id']);
    $traDto->setNombre($_POST['nombre']);
    $traDto->setNitTransportadora($_POST['nit']);

    $mensaje = $traDao->registrarTransportadora($traDto);

    header("Location: ../index.php?mensaje=" . $mensaje);
}

if (isset($_POST['modificar'])) {

    $traDao = new TransportadoraDao();
    $traDto = new TransportadoraDto();

    $traDto->setId($_POST['id']);
    $traDto->setNombre($_POST['nombre']);
    $traDto->setNitTransportadora($_POST['nit']);

   
    $mensaje = $traDao->modificarTransportadora($traDto);

    header("Location: ../Registros.php?mensaje=" . $mensaje);
}

if (isset($_GET['id'])) {

    $traDao = new TransportadoraDao();
  
   
    $mensaje = $traDao->eliminarTransportadora($_GET['id']);

    header("Location: ../Registros.php?mensaje=" . $mensaje);
}






    