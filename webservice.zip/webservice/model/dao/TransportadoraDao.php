<?php

class TransportadoraDao {

    public function registrarTransportadora(TransportadoraDto $tra) {

        $conn = Conexion::singleton()->obtenerConexion();

        $mensaje = "";
        try {
            $id = $tra->getId();
            $nombre = $tra->getNombre();
            $nit = $tra->getNitTransportadora();

            $consult = $conn->prepare("SELECT * FROM tbl_transportadora  WHERE id_transportadora=?");
            $consult->bindParam(1, $id);
            $consult->execute();
            $row = $consult->rowCount();

            if ($row > 0) {
                $mensaje = "Este registro ya esta  en base de datos";
            }
            else {

                $query = $conn->prepare("INSERT INTO tbl_transportadora VALUES(?,?,?)");
                $query->bindParam(1, $id);
                $query->bindParam(2, $nombre);
                $query->bindParam(3, $nit);
                $query->execute();
                $cuenta = $query->rowCount();
                if ($cuenta > 0) {
                    $mensaje = "Transportadora registrada en base de datos" . $cuenta;
                }
                else {
                    $mensaje = "No se pudo ingresar el registro";
                }
            }
        }
        catch (Exception $ex) {

            $mensaje = $ex->getMessage();
        }


        return $mensaje;
    }

    public function modificarTransportadora(TransportadoraDto $tra) {
        $id = $tra->getId();
        $nombre = $tra->getNombre();
        $nit = $tra->getNitTransportadora();

        $conn = Conexion::singleton()->obtenerConexion();

        $mensaje = "";
        try {
            $query = $conn->prepare("UPDATE tbl_transportadora SET nombre=?,nit_transportadora=? where id_transportadora=?");


            $query->bindParam(1, $nombre, PDO::PARAM_STR);
            $query->bindParam(2, $nit, PDO::PARAM_STR);
            $query->bindParam(3, $id, PDO::PARAM_INT);


            $query->execute();
            $mensaje = "Transportadora Actualizada";
        }
        catch (Exception $ex) {

            $mensaje = $ex->getMessage();
        }

        $conn = null;
        return $mensaje;
    }

    public function eliminarTransportadora($idTra) {

        $conn = Conexion::obtenerConexion();

        $mensaje = "";
        try {
            $query = $conn->prepare("DELETE FROM tbl_transportadora where id_transportadora=?");
            $query->bindParam(1, $idTra);

            $query->execute();
            $mensaje = "Registro eliminado";
        }
        catch (Exception $ex) {

            $mensaje = $ex->getMessage();
        }

        $conn = null;
        return $mensaje;
    }

    public function listarTransportadoras() {

        $conn = Conexion::singleton()->obtenerConexion();
        try {
            $query = $conn->prepare("SELECT * FROM tbl_transportadora");
            $query->execute();
            return $query->fetchAll();
        }
        catch (Exception $ex) {

            echo 'ERROR' . $ex->getMessage();
        }

        $conn = null;
    }

    public function listarUno($idTrans) {
        $id = $idTrans;
        $conn = Conexion::singleton()->obtenerConexion();


        try {
            $query = $conn->prepare("SELECT * FROM tbl_transportadora WHERE id_transportadora=?");
            $query->bindParam(1, $id);
            $query->execute();
            return $query->fetch();
        }
        catch (Exception $ex) {

            echo 'Error' . $ex->getMessage();
        }

        $conn = null;
    }

}
