<?php

class TransportadoraDto{
    
    private $id;
    private $nombre;
    private $nitTransportadora;
    
    function __construct() {
        
    }

    function getId() {
        return $this->id;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getNitTransportadora() {
        return $this->nitTransportadora;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setNombre($nombre) {
        $this->nombre = $nombre;
    }

    function setNitTransportadora($nitTransportadora) {
        $this->nitTransportadora = $nitTransportadora;
    }


    
}