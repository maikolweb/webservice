<?php

require_once '../config/Conexion.php';
require_once '../model/dao/AerolineaDao.php';
require_once '../model/dto/AerolineaDto.php';



if (isset($_POST['registrar'])) {

    $AeroDao = new AerolineaDao();
    $AeroDto = new AerolineaDto();

    $AeroDto->setId($_POST['id']);
    $AeroDto->setAerolinea($_POST['aerolineaNombre']);
   
   
 
    
    $mensaje = $AeroDao->registrarAerolinea($AeroDto);

    header("Location: ../index.php?mensaje=" . $mensaje);
}

if (isset($_POST['modificar'])) {

    $AeroDao = new AerolineaDao();
    $AeroDto = new AerolineaDto();

    $AeroDto->setId($_POST['id']);
    $AeroDto->setAerolinea($_POST['aerolinea']);


   
    $mensaje = $AeroDao->modificarAerolinea($AeroDto);

    header("Location: ../Registros.php?mensaje=" . $mensaje);
}

if (isset($_GET['id'])) {

    $AeroDao = new AerolineaDao();
  
   
    $mensaje = $AeroDao->eliminarAerolinea($_GET['id']);

    header("Location: ../Registros.php?mensaje=" . $mensaje);
}






    