<?php

header('Content-Type: text/html; charset=ISO-8859-1');
require_once('lib/nusoap.php');

class ServicioWeb {

    private $url;
    private $parameters = array();
    private $cunsult = array();

    public function __construct() {
        $this->url = "http://pruebas-webservices.ica.gov.co:83/wsCostanciasICA/?wsdl";
        $this->parameters = [
          "id_cultivo"=> "21",
          "usuario" => "VUELVEN12",
          "contrasena" => "Cargonet2018*",
          "ip_equipo" => "192.168.1.108",
        ];
    }

    function getUrl() {
        return $this->url;
    }

    function getParameters() {
        return $this->parameters;
    }

    function getCunsult() {
        return $this->cunsult;
    }

    function setUrl($url) {
        $this->url = $url;
    }

    function setParameters($parameters) {
        $this->parameters = $parameters;
    }

    function setCunsult($cunsult) {
        $this->cunsult = $cunsult;
    }

    public function consulta() {

        $cliente = new nusoap_client($this->url, "wsdl");

        if ($cliente->fault) { // si
            $error = $cliente->getError();
            if ($error) { // Hubo algun error
                echo 'Error:  ' . $cliente->faultstring;
            }
            die();
        }

        //llamando al método y pasándole el array con los parámetros
        $cunsult = $cliente->call('consultarAerolineas', $this->parameters);
        
        $result=$cunsult['consultarAerolineasResult']['VO_AEROLINEA'];
       
    
        return $result;
    }

}
