<?php

class Conexion {

    private static $instance = null;

    private function __construct() {
        
    }

    public static function singleton() {
        if (self::$instance == null) {
            self::$instance = new Conexion();
        }
        return self::$instance;
    }

    public function obtenerConexion() {
        $conn = null;

        try {
            $conn = new PDO("mysql:host=localhost;dbname=aerolinea", "root", "");
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        catch (PDOException $e) {
            echo 'ERROR: ' . $e->getMessage();
            die();
        }

        return $conn;
    }

    // Evita que el objeto se pueda clonar
    public function __clone() {
        trigger_error('La clonación de este objeto no está permitida', E_USER_ERROR);
    }

}
