<?php

return array(
  "host"=> "localhost",
  "user"=> "root",
  "pass"=> "",
  "database"=> "Transportadora",
  "charset"=> "utf8",
);