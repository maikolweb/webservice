<?php

class AerolineaDao {

    public function registrarAerolinea(AerolineaDto $aer) {

        $conn = Conexion::singleton()->obtenerConexion();

        $mensaje = "";
        try {
            $id = $aer->getId();
            $aerolinea = $aer->getAerolinea();
          
          
            $consult = $conn->prepare("SELECT * FROM tbl_aerolinea  WHERE id=?");
            $consult->bindParam(1, $id);
            $consult->execute();
            $row = $consult->rowCount();

            if ($row > 0) {
                $mensaje = "Este registro ya esta  en base de datos";
            }
            else {

                $query = $conn->prepare("INSERT INTO tbl_aerolinea VALUES(?,?)");
                $query->bindParam(1, $id);
                $query->bindParam(2, $aerolinea);
               
                $query->execute();
                $cuenta = $query->rowCount();
                if ($cuenta > 0) {
                    $mensaje = "Aerolinea registrada en base de datos" . $cuenta;
                }
                else {
                    $mensaje = "No se pudo ingresar el registro";
                }
            }
        }
        catch (Exception $ex) {

            $mensaje = $ex->getMessage();
        }


        return $mensaje;
    }

    public function modificarAerolinea(AerolineaDto $aer) {
        $id = $aer->getId();
        $aerolinea = $aer->getAerolinea();
      

        $conn = Conexion::singleton()->obtenerConexion();

        $mensaje = "";
        try {
            $query = $conn->prepare("UPDATE tbl_aerolinea SET aerolinea=? where id=?");


            $query->bindParam(1, $aerolinea, PDO::PARAM_STR);
            $query->bindParam(2, $id, PDO::PARAM_INT);


            $query->execute();
            $mensaje = "Aerolinea Actualizada";
        }
        catch (Exception $ex) {

            $mensaje = $ex->getMessage();
        }

        $conn = null;
        return $mensaje;
    }

    public function eliminarAerolinea($idaero) {

        $conn = Conexion::obtenerConexion();

        $mensaje = "";
        try {
            $query = $conn->prepare("DELETE FROM tbl_aerolinea where id=?");
            $query->bindParam(1, $idaero);

            $query->execute();
            $mensaje = "Registro eliminado";
        }
        catch (Exception $ex) {

            $mensaje = $ex->getMessage();
        }

        $conn = null;
        return $mensaje;
    }

    public function listarAerolineas() {

        $conn = Conexion::singleton()->obtenerConexion();
        try {
            $query = $conn->prepare("SELECT * FROM tbl_aerolinea");
            $query->execute();
            return $query->fetchAll();
        }
        catch (Exception $ex) {

            echo 'ERROR' . $ex->getMessage();
        }

        $conn = null;
    }

    public function listarUno($idAero) {
        $id = $idAero;
        $conn = Conexion::singleton()->obtenerConexion();


        try {
            $query = $conn->prepare("SELECT * FROM tbl_aerolinea WHERE id=?");
            $query->bindParam(1, $id);
            $query->execute();
            return $query->fetch();
        }
        catch (Exception $ex) {

            echo 'Error' . $ex->getMessage();
        }

        $conn = null;
    }

}
